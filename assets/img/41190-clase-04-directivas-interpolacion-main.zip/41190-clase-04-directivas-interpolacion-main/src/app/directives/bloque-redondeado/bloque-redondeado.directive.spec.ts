import { BloqueRedondeadoDirective } from './bloque-redondeado.directive';

describe('BloqueRedondeadoDirective', () => {
  it('should create an instance', () => {
    const directive = new BloqueRedondeadoDirective();
    expect(directive).toBeTruthy();
  });
});
